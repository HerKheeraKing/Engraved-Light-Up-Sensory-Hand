#ifndef PanelManager_h
#define PanelManager_h

#include <esp_now.h>
#include <esp_wifi.h>
#include <BluetoothSerial.h>
#include <Preferences.h>
#include <esp_arduino_version.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

// === Check ESP32 Core Version (Must be 2.0.17) ===
#if (ESP_ARDUINO_VERSION_MAJOR != 2) || (ESP_ARDUINO_VERSION_MINOR != 0) || (ESP_ARDUINO_VERSION_PATCH != 17)
    #error "This library requires ESP32 core version 2.0.17 by Espressif Systems."
#endif

#define CHAR_BUFFER_SIZE 32
#define MAX_PANELS 64
#define HEARTBEAT_DELAY 2000

class PanelManager {
    public:
        PanelManager(String panelName, String panelPrefix = "Panel-", uint8_t channel = 1, bool debug = 0, unsigned long baud = 115200);
        void InitManager();
        
        String currentUser = "NULL";
        float maxBrightness = 100, minBrightness = 0, maxVolume = 100, minVolume = 0;
        
    private:
        enum SettingType { MaB, MiB, MaV, MiV };
        
        static void CommTask(void *pvParameters);
        void HandleLoopCalls();
        static void OnDataRecv(const uint8_t *mac_addr, const uint8_t *data, int data_len);
        static void OnDataSent(const uint8_t *mac_addr, esp_now_send_status_t status);
        void SendESPData(const char *message);
        void SendBTData(const char *message);
        void ScanForPeers();
        bool ManagePeers();
        char *SerialReadLineChar();
        bool ProcessMessage(char *cmd);
        void LoadPreferences();
        void SavePreferences();
        bool CheckIfSettingsChanged(float MaB, float MiB, float MaV, float MiV);
        bool CheckIfSettingChanged(SettingType st, float val);
        
        String panelName;
        String panelPrefix;
        uint8_t channel;
        static bool debug;
        static String recvString;
        esp_now_peer_info_t peers[MAX_PANELS];
        uint8_t curPeers = 0;
        unsigned long lastHeartbeat = 0;
        static BluetoothSerial SerialBT;
        Preferences prefs;
        String pref_namespace = "UserPrefs";
};

#endif