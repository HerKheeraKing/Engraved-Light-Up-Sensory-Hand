#include "PanelManager.h"

bool PanelManager::debug = false;
String PanelManager::recvString = "";
BluetoothSerial PanelManager::SerialBT;

PanelManager::PanelManager(String panelName, String panelPrefix, uint8_t channel, bool debug, unsigned long baud) : panelName(panelName), panelPrefix(panelPrefix), channel(channel) {
    PanelManager::debug = debug;
    if (debug)
        Serial.begin(baud);
}

void PanelManager::InitManager() {
    // Load Default/Prior Saved settings for panel
    LoadPreferences();
    // Start the actual communication for the entire panel (ESP-NOW and Bluetooth)
    xTaskCreatePinnedToCore(CommTask, "CommTask", 8192, (void*)this, 0, NULL, 0);
}

void PanelManager::CommTask(void *pvParameters) {
    // Make sure panel is valid
    PanelManager *panel = (PanelManager*)pvParameters;
    if (!panel) {
        if (panel->debug)
            Serial.println("Error: PanelManager is NULL");
        ESP.restart();
    }
    // Initliaze the Bluetooth
    SerialBT.begin(panel->panelName);
    // Initialize the Wi-Fi
    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    cfg.wifi_task_core_id = 0;
    esp_err_t result = esp_wifi_init(&cfg);
    if (result != ESP_OK) {
        if (panel->debug)
            Serial.printf("Failed to initialize Wi-Fi: %s\n", esp_err_to_name(result));
        ESP.restart();
    }
    // Set Wi-Fi mode to APSTA
    result = esp_wifi_set_mode(WIFI_MODE_APSTA);
    if (result != ESP_OK) {
        if (panel->debug)
            Serial.printf("Failed to set Wi-Fi mode: %s\n", esp_err_to_name(result));
        ESP.restart();
    }
    // Set the Wi-Fi channel
    esp_wifi_set_channel(panel->channel, WIFI_SECOND_CHAN_NONE);
    // Configure the AP settings
    wifi_config_t ap_config = {};
    strncpy((char*)ap_config.ap.ssid, panel->panelName.c_str(), sizeof(ap_config.ap.ssid) - 1);
    strncpy((char*)ap_config.ap.password, "thoehogeragiearhogiher", sizeof(ap_config.ap.password) - 1);
    ap_config.ap.ssid_len = strlen((char*)ap_config.ap.ssid);
    ap_config.ap.channel = panel->channel;
    ap_config.ap.authmode = WIFI_AUTH_WPA2_PSK;
    ap_config.ap.max_connection = 4;
    ap_config.ap.ssid_hidden = 0;
    // Set the Wi-Fi configuration
    result = esp_wifi_set_config(WIFI_IF_AP, &ap_config);
    if (result != ESP_OK) {
        if (panel->debug)
            Serial.printf("Failed to set Wi-Fi config: %s\n", esp_err_to_name(result));
        ESP.restart();
    }
    // Start the Wi-Fi
    result = esp_wifi_start();
    if (result != ESP_OK) {
        if (panel->debug)
            Serial.printf("Failed to start Wi-Fi: %s\n", esp_err_to_name(result));
        ESP.restart();
    }
    // Delay to allow Wi-Fi to stabilize
    vTaskDelay(100);
    // Debugging output
    if (panel->debug) {
        Serial.print("Device SSID: ");
        Serial.println(panel->panelName);
        tcpip_adapter_ip_info_t ip_info;
        tcpip_adapter_get_ip_info(TCPIP_ADAPTER_IF_AP, &ip_info);
        Serial.print("AP IP: ");
        Serial.println(ip4addr_ntoa(&ip_info.ip));
    }
    // Initialize ESP-NOW
    result = esp_now_init();
    if (result != ESP_OK) {
        if (panel->debug)
            Serial.printf("ESP-NOW Init Failed: %s\n", esp_err_to_name(result));
        ESP.restart();
    }
    if (panel->debug)
        Serial.println("ESP-NOW Init Success");
    // Register callbacks for ESP-NOW
    esp_now_register_recv_cb(OnDataRecv);
    esp_now_register_send_cb(OnDataSent);
    while (true) {
        // Keep task alive and scan for other panels
        panel->HandleLoopCalls();
        vTaskDelay(100 / portTICK_PERIOD_MS);
    }
    vTaskSuspend(NULL);
}

void PanelManager::OnDataRecv(const uint8_t *mac_addr, const uint8_t *data, int data_len) {
    // Handle incoming data from other panels
    String receivedData = "";
    if (data_len > 0) {
        for (int i = 0; i < data_len; i++)
            receivedData += (char)data[i];
        recvString = receivedData;
    }
    if (debug) {
        char macStr[18];
        snprintf(macStr, sizeof(macStr), "%02x:%02x:%02x:%02x:%02x:%02x", mac_addr[0], mac_addr[1], mac_addr[2], mac_addr[3], mac_addr[4], mac_addr[5]);
        Serial.print("Last Packet Recv from: ");
        Serial.println(macStr);
        Serial.print("Last Packet Recv Data: ");
        Serial.println(receivedData);
    }
}

void PanelManager::OnDataSent(const uint8_t *mac_addr, esp_now_send_status_t status) {
    if (debug) {
        char macStr[18];
        snprintf(macStr, sizeof(macStr), "%02x:%02x:%02x:%02x:%02x:%02x", mac_addr[0], mac_addr[1], mac_addr[2], mac_addr[3], mac_addr[4], mac_addr[5]);
        Serial.print("Last Packet Sent to: ");
        Serial.println(macStr);
        Serial.print("Last Packet Send Status: ");
        Serial.println(status == ESP_NOW_SEND_SUCCESS ? "Delivery Success" : "Delivery Fail");
    }
}

void PanelManager::SendESPData(const char *message) {
    // Send data to other panels using ESP-NOW
    for (int i = 0; i < curPeers; i++) {
        esp_now_send(peers[i].peer_addr, (uint8_t *)message, strlen(message));
        if (debug) {
            char macStr[18];
            snprintf(macStr, sizeof(macStr), "%02x:%02x:%02x:%02x:%02x:%02x", peers[i].peer_addr[0], peers[i].peer_addr[1], peers[i].peer_addr[2], peers[i].peer_addr[3], peers[i].peer_addr[4], peers[i].peer_addr[5]);
            Serial.print("Message sent to peer: ");
            Serial.println(macStr);
        }
    }
}

void PanelManager::SendBTData(const char *message) {
    // Send data to the app manager
    SerialBT.println(message);
    if (debug) {
        Serial.print("BT Message sent: "); Serial.println(message);
    }
}

void PanelManager::ScanForPeers() {
    if (curPeers >= MAX_PANELS) {
        if (debug)
            Serial.println("Max amount of panels connected.");
        return;
    }
    wifi_scan_config_t scan_config = {};
    scan_config.show_hidden = false;  // Don't show hidden networks
    scan_config.scan_type = WIFI_SCAN_TYPE_ACTIVE;
    scan_config.channel = channel;    // Scan only on the specified channel
    scan_config.scan_time.active.min = 300;  // Min scan time per channel (ms)
    // Start WiFi scan
    esp_wifi_scan_start(&scan_config, true);  // Blocking scan
    // Get number of found networks
    uint16_t scanResults = 0;
    esp_wifi_scan_get_ap_num(&scanResults);
    bool peerFound = false;
    if (scanResults == 0 && debug)
        Serial.println("No WiFi devices in AP Mode found");
    else {
        if (debug) {
            Serial.print("Found "); Serial.print(scanResults); Serial.println(" devices");
        }
        // Retrieve scan results
        wifi_ap_record_t ap_records[scanResults];  
        esp_wifi_scan_get_ap_records(&scanResults, ap_records);
        for (int i = 0; i < scanResults; ++i) {
            String SSID = String((char *)ap_records[i].ssid);
            String BSSIDstr = "";
            char bssid[18];
            sprintf(bssid, "%02X:%02X:%02X:%02X:%02X:%02X", ap_records[i].bssid[0], ap_records[i].bssid[1], ap_records[i].bssid[2], ap_records[i].bssid[3], ap_records[i].bssid[4], ap_records[i].bssid[5]);
            BSSIDstr = String(bssid);
            int32_t RSSI = ap_records[i].rssi;
            // Check if the current device starts with the prefix
            if (SSID.startsWith(panelPrefix)) {
                // Get BSSID => Mac Address of the Peer
                esp_now_peer_info_t newPeer = {}; // Zero-initialize
                memcpy(newPeer.peer_addr, ap_records[i].bssid, 6);
                newPeer.channel = channel;  // Pick a channel
                newPeer.encrypt = 0;  // No encryption
                newPeer.ifidx = WIFI_IF_STA;  // Set correct interface
                bool wasPeerConnected = false;
                uint8_t emptyMac[6] = {0, 0, 0, 0, 0, 0};
                for (int j = 0; j < curPeers; j++) {
                    if (memcmp(peers[j].peer_addr, emptyMac, 6) == 0)
                        break;
                    if (memcmp(peers[j].peer_addr, newPeer.peer_addr, 6) == 0) {
                        wasPeerConnected = true;
                        break;
                    }
                }
                if (!wasPeerConnected) {
                    peers[curPeers++] = newPeer; // Add this peer to the array
                    if (debug) {
                        Serial.println("Found a Peer.");
                        Serial.print(i + 1); Serial.print(": "); Serial.print(SSID);
                        Serial.print(" ["); Serial.print(BSSIDstr); Serial.print("] ");
                        Serial.print(" ("); Serial.print(RSSI); Serial.println(")");
                    }
                }
                peerFound = true;
            }
        }
    }
    if (!peerFound && debug)
        Serial.println("No Peers Found, trying again.");
}

bool PanelManager::ManagePeers() {
    bool allPaired = true;
    for (int i = 0; i < curPeers; i++) {
        bool exists = esp_now_is_peer_exist(peers[i].peer_addr);
        if (exists) {
            if (debug) {
                char macStr[18];
                snprintf(macStr, sizeof(macStr), "%02x:%02x:%02x:%02x:%02x:%02x", peers[i].peer_addr[0], peers[i].peer_addr[1], peers[i].peer_addr[2], peers[i].peer_addr[3], peers[i].peer_addr[4], peers[i].peer_addr[5]);
                Serial.print("Peer already paired: ");
                Serial.println(macStr);
            }
        } else {
            esp_err_t addStatus = esp_now_add_peer(&peers[i]);
            if (addStatus != ESP_OK) {
                allPaired = false;
                if (debug) {
                    Serial.print("Failed to pair with peer: ");
                    char macStr[18];
                    snprintf(macStr, sizeof(macStr), "%02x:%02x:%02x:%02x:%02x:%02x", peers[i].peer_addr[0], peers[i].peer_addr[1], peers[i].peer_addr[2], peers[i].peer_addr[3], peers[i].peer_addr[4], peers[i].peer_addr[5]);
                    Serial.println(macStr);
                }
            }
        }
    }
    return allPaired;
}

char *PanelManager::SerialReadLineChar() {
    char c;                                       
    bool msgReceived = false;                     
    static uint8_t index = 0;
    static char charBuff[CHAR_BUFFER_SIZE] = {0};
    while (SerialBT.available() > 0) {
        c = (char)SerialBT.read();
        if ((c == '\r') || (c == '\n')) {
            if (index == 0)
                continue;
            charBuff[index] = '\0';
            msgReceived = true;
            index = 0;
            break;
        }
        if (!msgReceived)
            charBuff[index++] = c;
        delay(1);
    }
    return (msgReceived ? charBuff : nullptr);
}

bool PanelManager::ProcessMessage(char *cmd) {
    char *header = strtok(cmd, ":");
    char *body = strtok(NULL, "");
    if (header == nullptr || body == nullptr) {
        Serial.println("Error: Command not recognized, or invalid value");
        return false;
    }
    //USER:name,maxBrightness,minBrightness,maxVolume,minVolume
    if (strcasecmp(header, "USER") == 0) {
        char *user = strtok(body, ",");
        char *maxB_str = strtok(nullptr, ",");
        char *minB_str = strtok(nullptr, ",");
        char *maxV_str = strtok(nullptr, ",");
        char *minV_str = strtok(nullptr, ",");
        if (user && maxB_str && minB_str && maxV_str && minV_str) {
            if (!CheckIfSettingsChanged(atof(maxB_str), atof(minB_str), atof(maxV_str), atof(minV_str)))
                return false;
            currentUser = String(user);
            maxBrightness = atof(maxB_str);
            minBrightness = atof(minB_str);
            maxVolume = atof(maxV_str);
            minVolume = atof(minV_str);
            SavePreferences();
            String msg = "USER:" + currentUser + "," + String(maxBrightness) + "," + String(minBrightness) + "," + String(maxVolume) + "," + String(minVolume);
            SendESPData(msg.c_str());
            return true;
        }
    }
    //SETV:type=val
    else if (strcasecmp(header, "SETV") == 0) {
        char *varType = strtok(body, "=");
        char *val = strtok(nullptr, "");
        if (varType && val) {
            if (strcasecmp(varType, "MaxBright") == 0) {
                if (!CheckIfSettingChanged(MaB, atof(val)))
                    return false;
                maxBrightness = atof(val);
            }
            else if (strcasecmp(varType, "MinBright") == 0) {
                if (!CheckIfSettingChanged(MiB, atof(val)))
                    return false;
                minBrightness = atof(val);
            }
            else if (strcasecmp(varType, "MaxVolume") == 0) {
                if (!CheckIfSettingChanged(MaV, atof(val)))
                    return false;
                maxVolume = atof(val);
            }
            else if (strcasecmp(varType, "MinVolume") == 0) {
                if (!CheckIfSettingChanged(MiV, atof(val)))
                    return false;
                minVolume = atof(val);
            }
            SavePreferences();
            String msg = "SETV:" + String(varType) + "=" + String(val);
            SendESPData(msg.c_str());
            return true;
        }
    }
    return false;
}

bool PanelManager::CheckIfSettingChanged(SettingType st, float val) { return ((st == MiB && val <= maxBrightness) || (st == MaB && val >= minBrightness) || (st == MiV && val <= maxVolume) || (st == MaV && val >= minVolume)); }

bool PanelManager::CheckIfSettingsChanged(float maxB, float minB, float maxV, float minV) { return (minB < maxB && minV < maxV); }

void PanelManager::SavePreferences() {
    prefs.begin(pref_namespace.c_str());
    prefs.putString("username", currentUser);
    prefs.putFloat("maxBrightness", maxBrightness);
    prefs.putFloat("minBrightness", minBrightness);
    prefs.putFloat("maxVolume", maxVolume);
    prefs.putFloat("minVolume", minVolume);
    prefs.end();
}

void PanelManager::LoadPreferences() {
    prefs.begin(pref_namespace.c_str());
    currentUser = prefs.getString("username", "NULL");
    maxBrightness = prefs.getFloat("maxBrightness", 100);
    minBrightness = prefs.getFloat("minBrightness", 0);
    maxVolume = prefs.getFloat("maxVolume", 100);
    minVolume = prefs.getFloat("minVolume", 0);
    prefs.end();
}

void PanelManager::HandleLoopCalls() {
    ScanForPeers();
    if (curPeers != 0 && recvString != "") {
        char* cmd = new char[recvString.length() + 1];
        strcpy(cmd, recvString.c_str());
        ProcessMessage(cmd);
        recvString = "";
        delete[] cmd;
    }
    char *msg = SerialReadLineChar();
    if (msg != nullptr) {
        if (strcasecmp(msg, "Init") == 0) {
            SendBTData(("DefaultUser:" + String(currentUser == "NULL" ? "1" : "0")).c_str());
            SendBTData(("USER:" + currentUser).c_str());
        }
        else if (curPeers != 0 && ManagePeers()) 
            ProcessMessage(msg);
    }
}
